"""
MASTER RESULTS AGGREGATOR (NEW)
====================================
Run this LAST, after exp1-exp8 have produced their JSON/CSV outputs.

Purpose: every experiment script above writes its own results file in
its own format, on the assumption it will be run across multiple Kaggle
sessions over several days. Without a single script that reads all of
them back in, you are left manually copying numbers into LaTeX tables —
the exact error-prone step that produces the kind of inconsistency
reviewers notice (e.g. a number in Table IV that doesn't match the
abstract). This script is the single source of truth: it reads every
results file, checks for completeness, and emits camera-ready LaTeX.

WHAT IT PRODUCES:
  - completeness_report.txt   : which experiments are done / missing
  - table_IV_main_results.tex
  - table_V_baselines.tex
  - table_VI_ablation.tex
  - table_VII_xai_metrics.tex
  - table_VIII_robustness.tex
  - table_IX_prototype_quality.tex
  - table_X_efficiency.tex
  - all_results_manifest.json  (everything, machine-readable, for
    supplementary material / reproducibility appendix)

HOW TO USE:
  Run locally or in a final Kaggle session after downloading all
  individual results directories into a single RESULTS_ROOT.
"""

import os, json, glob
import pandas as pd
import numpy as np

# ─── CONFIG — adjust to wherever you've collected all results dirs ──────────
RESULTS_ROOT = "/kaggle/working"
OUT_DIR      = "/kaggle/working/final_tables"
os.makedirs(OUT_DIR, exist_ok=True)

PATHS = {
    'ablation':        f"{RESULTS_ROOT}/ablation_results_summary.csv",
    'multiseed':       f"{RESULTS_ROOT}/multiseed/final_stats.json",
    'causal_shap':     f"{RESULTS_ROOT}/causal_shap/causal_shap_results.json",
    'pipnet':          f"{RESULTS_ROOT}/pipnet/pipnet_summary.json",
    'xai_metrics':     f"{RESULTS_ROOT}/xai_metrics/xai_metrics.json",
    'robustness':      f"{RESULTS_ROOT}/robustness/robustness_results.json",
    'prototype':       f"{RESULTS_ROOT}/prototype_analysis/prototype_analysis.json",
    'efficiency':      f"{RESULTS_ROOT}/efficiency/efficiency_results.json",
}

REQUIRED_FOR_SUBMISSION = [
    'multiseed', 'ablation', 'pipnet', 'causal_shap', 'robustness',
]
RECOMMENDED = ['xai_metrics', 'prototype', 'efficiency']


def safe_load_json(path):
    if os.path.exists(path):
        with open(path) as f: return json.load(f)
    return None

def safe_load_csv(path):
    if os.path.exists(path):
        return pd.read_csv(path)
    return None

# ════════════════════════════════════════════════════════════════════════════
# COMPLETENESS CHECK
# ════════════════════════════════════════════════════════════════════════════

def check_completeness():
    print("="*70)
    print("EXPERIMENT COMPLETENESS CHECK")
    print("="*70)
    status = {}
    for key, path in PATHS.items():
        exists = os.path.exists(path)
        status[key] = exists
        tag = "✅" if exists else "❌"
        req = " [REQUIRED]" if key in REQUIRED_FOR_SUBMISSION else " [recommended]"
        print(f"  {tag} {key:<15}{req:<15} {path}")

    missing_required = [k for k in REQUIRED_FOR_SUBMISSION if not status[k]]
    missing_recommended = [k for k in RECOMMENDED if not status[k]]

    print(f"\n  Required complete:    {len(REQUIRED_FOR_SUBMISSION)-len(missing_required)}"
          f"/{len(REQUIRED_FOR_SUBMISSION)}")
    print(f"  Recommended complete: {len(RECOMMENDED)-len(missing_recommended)}"
          f"/{len(RECOMMENDED)}")

    if missing_required:
        print(f"\n  ⚠️  CANNOT GENERATE FULL PAPER — missing required: "
              f"{missing_required}")
    else:
        print(f"\n  ✓ All required experiments complete. Safe to draft "
              f"Results/Explainability sections.")

    with open(os.path.join(OUT_DIR, 'completeness_report.txt'), 'w') as f:
        f.write(f"Completeness check\n{'='*40}\n")
        for k, v in status.items():
            f.write(f"{'DONE' if v else 'MISSING':<10} {k}\n")
        f.write(f"\nMissing required: {missing_required}\n")
        f.write(f"Missing recommended: {missing_recommended}\n")

    return status

# ════════════════════════════════════════════════════════════════════════════
# TABLE IV — MULTI-SEED MAIN RESULTS
# ════════════════════════════════════════════════════════════════════════════

def build_table_iv():
    data = safe_load_json(PATHS['multiseed'])
    if not data:
        print("  [Table IV] multiseed results not found — skipping")
        return

    pnet, bb, tt = data['pnet'], data['blackbox'], data.get('ttest')

    lines = [
        r"\begin{table}[t]",
        r"\caption{POWER-ProtoPNet Performance on PlantWild v3 "
        r"(38 classes, 150 images/class; multi-seed)}",
        r"\label{tab:main_results}",
        r"\begin{tabular}{lcc}",
        r"\toprule",
        r"Metric & POWER-ProtoPNet & ConvNeXt-Tiny (BB) \\",
        r"\midrule",
        f"Test Acc.\\ (\\%) & {pnet['mean']:.2f} $\\pm$ {pnet['std']:.2f} & "
        f"{bb['mean']:.2f} $\\pm$ {bb['std']:.2f} \\\\",
        f"95\\% CI & [{pnet['ci_lo']:.2f}, {pnet['ci_hi']:.2f}] & "
        f"[{bb['ci_lo']:.2f}, {bb['ci_hi']:.2f}] \\\\",
        f"$n$ seeds & {pnet['n']} & {bb['n']} \\\\",
    ]
    if tt:
        sig = "p<0.05" if tt['significant_at_05'] else "n.s."
        lines.append(r"\midrule")
        lines.append(f"Paired $t$-test & "
                     f"\\multicolumn{{2}}{{c}}{{$\\Delta$={tt['mean_diff']:+.2f}pp, "
                     f"$t$={tt['t_stat']:.2f}, $p$={tt['p_value']:.3f} ({sig})}} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]

    out_path = os.path.join(OUT_DIR, 'table_IV_main_results.tex')
    with open(out_path, 'w') as f: f.write("\n".join(lines))
    print(f"  [Table IV] written to {out_path}")
    return data

# ════════════════════════════════════════════════════════════════════════════
# TABLE V — BASELINE COMPARISON (incl. PIPNet)
# ════════════════════════════════════════════════════════════════════════════

def build_table_v():
    ms = safe_load_json(PATHS['multiseed'])
    pp = safe_load_json(PATHS['pipnet'])

    rows = [
        ("ResNet-50 [12]",        "ResNet-50",     "No",  "99.21", "—",   "25.6M"),
        ("EfficientNet-B4 [14]",  "Eff.-B4",       "No",  "99.43", "—",   "19.3M"),
    ]
    if ms:
        bb = ms['blackbox']
        rows.append(("ConvNeXt-Tiny (BB)", "ConvNeXt-Tiny", "No",
                    f"{bb['mean']:.2f}", f"{bb['std']:.2f}", "28.6M"))
    rows += [
        ("ProtoPNet [8]",  "ResNet-50", "Yes", "97.40", "—", "26.8M"),
        ("ProtoTree [9]",  "ResNet-50", "Yes", "96.95", "—", "26.2M"),
    ]
    if pp:
        rows.append(("PIPNet [10]", "ConvNeXt-Tiny", "Yes",
                    f"{pp['mean_acc']:.2f}", f"{pp['std_acc']:.2f}",
                    f"~{pp['n_params_M']:.0f}M"))
    else:
        rows.append(("PIPNet [10]", "ConvNeXt-Tiny", "Yes",
                    "PENDING", "—", "~14M"))
    if ms:
        pn = ms['pnet']
        rows.append(("\\textbf{POWER-ProtoPNet}", "ConvNeXt-Tiny", "Yes",
                    f"\\textbf{{{pn['mean']:.2f}}}", f"{pn['std']:.2f}", "~29M"))

    lines = [
        r"\begin{table}[t]",
        r"\caption{Baseline Comparison on PlantWild v3. "
        r"All methods trained on identical splits; multi-seed where available.}",
        r"\label{tab:baselines}",
        r"\begin{tabular}{lcccc}",
        r"\toprule",
        r"Method & Backbone & Interp. & Acc.\ (\%) & Params \\",
        r"\midrule",
    ]
    for name, bbone, interp, acc, std, params in rows:
        std_str = f"$\\pm${std}" if std not in ("—","PENDING") else ""
        lines.append(f"{name} & {bbone} & {interp} & {acc}{std_str} & {params} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]

    out_path = os.path.join(OUT_DIR, 'table_V_baselines.tex')
    with open(out_path, 'w') as f: f.write("\n".join(lines))
    print(f"  [Table V] written to {out_path}")
    if not pp:
        print("    ⚠️  PIPNet result still PENDING — table has placeholder")

# ════════════════════════════════════════════════════════════════════════════
# TABLE VI — ABLATION STUDY
# ════════════════════════════════════════════════════════════════════════════

def build_table_vi():
    df = safe_load_csv(PATHS['ablation'])
    if df is None:
        print("  [Table VI] ablation results not found — skipping")
        return

    lines = [
        r"\begin{table}[t]",
        r"\caption{Ablation Study on PlantWild v3 "
        r"(mean $\pm$ std over available seeds).}",
        r"\label{tab:ablation}",
        r"\begin{tabular}{lccc}",
        r"\toprule",
        r"Configuration & Acc.\ (\%) & $\Delta$ vs.\ Full (pp) & Params (M) \\",
        r"\midrule",
    ]
    for variant in df['Variant'].unique():
        row = df[df['Variant']==variant].iloc[0]
        mean_acc = row['Mean(%)']
        std_acc  = row.get('Std(%)', 0)
        lines.append(f"{variant} & {mean_acc:.2f}$\\pm${std_acc:.2f} & "
                     f"{mean_acc-99.65:+.2f} & — \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]

    out_path = os.path.join(OUT_DIR, 'table_VI_ablation.tex')
    with open(out_path, 'w') as f: f.write("\n".join(lines))
    print(f"  [Table VI] written to {out_path}")

# ════════════════════════════════════════════════════════════════════════════
# TABLE VII — XAI QUANTITATIVE METRICS
# ════════════════════════════════════════════════════════════════════════════

def build_table_vii():
    data = safe_load_json(PATHS['xai_metrics'])
    if not data:
        print("  [Table VII] XAI metrics not found — skipping")
        return

    id_s = data.get('insertion_deletion_shap', {})
    id_g = data.get('insertion_deletion_gradcam', {})
    pg_s = data.get('pointing_game_shap', {})
    pg_g = data.get('pointing_game_gradcam', {})
    cons = data.get('attribution_consistency', {})

    lines = [
        r"\begin{table}[t]",
        r"\caption{Quantitative Explainability Evaluation.}",
        r"\label{tab:xai_metrics}",
        r"\begin{tabular}{lcc}",
        r"\toprule",
        r"Metric & SHAP & GradCAM++ \\",
        r"\midrule",
        f"Insertion AUC $\\uparrow$ & "
        f"{id_s.get('auc_ins_mean',0):.3f}$\\pm${id_s.get('auc_ins_std',0):.3f} & "
        f"{id_g.get('auc_ins_mean',0):.3f}$\\pm${id_g.get('auc_ins_std',0):.3f} \\\\",
        f"Deletion AUC $\\downarrow$ & "
        f"{id_s.get('auc_del_mean',0):.3f}$\\pm${id_s.get('auc_del_std',0):.3f} & "
        f"{id_g.get('auc_del_mean',0):.3f}$\\pm${id_g.get('auc_del_std',0):.3f} \\\\",
        f"Pointing Game (\\%) $\\uparrow$ & "
        f"{pg_s.get('pointing_game_acc',0)*100:.1f} & "
        f"{pg_g.get('pointing_game_acc',0)*100:.1f} \\\\",
        f"Energy PG (\\%) $\\uparrow$ & "
        f"{pg_s.get('energy_pg_mean',0)*100:.1f} & "
        f"{pg_g.get('energy_pg_mean',0)*100:.1f} \\\\",
        r"\midrule",
        f"Attribution consistency (SSIM) & "
        f"\\multicolumn{{2}}{{c}}{{{cons.get('mean_ssim',0):.3f}"
        f"$\\pm${cons.get('std_ssim',0):.3f}}} \\\\",
        r"\bottomrule", r"\end{tabular}", r"\end{table}",
    ]
    out_path = os.path.join(OUT_DIR, 'table_VII_xai_metrics.tex')
    with open(out_path, 'w') as f: f.write("\n".join(lines))
    print(f"  [Table VII] written to {out_path}")

# ════════════════════════════════════════════════════════════════════════════
# TABLE VIII — ROBUSTNESS
# ════════════════════════════════════════════════════════════════════════════

def build_table_viii():
    data = safe_load_json(PATHS['robustness'])
    if not data:
        print("  [Table VIII] robustness results not found — skipping")
        return

    p1 = data.get('probe1_background_swap', {})
    p2 = data.get('probe2_corruption', {})

    lines = [
        r"\begin{table}[t]",
        r"\caption{Field-Condition Robustness Evaluation.}",
        r"\label{tab:robustness}",
        r"\begin{tabular}{lccc}",
        r"\toprule",
        r"Model & Orig.\ Acc.\ (\%) & BG-Swap Acc.\ (\%) & mCE (\%) \\",
        r"\midrule",
    ]
    summary = p2.get('_summary', {})
    for name in ['POWER-ProtoPNet', 'BlackBox']:
        bg = p1.get(name, {})
        mce = summary.get(name, {}).get('mCE', '—')
        lines.append(
            f"{name} & {bg.get('original_acc','—')} & "
            f"{bg.get('swapped_acc','—')} ({bg.get('delta_pp',0):+.2f}pp) & "
            f"{mce} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]

    out_path = os.path.join(OUT_DIR, 'table_VIII_robustness.tex')
    with open(out_path, 'w') as f: f.write("\n".join(lines))
    print(f"  [Table VIII] written to {out_path}")

# ════════════════════════════════════════════════════════════════════════════
# TABLE IX — PROTOTYPE QUALITY
# ════════════════════════════════════════════════════════════════════════════

def build_table_ix():
    data = safe_load_json(PATHS['prototype'])
    if not data:
        print("  [Table IX] prototype analysis not found — skipping")
        return

    pur = data.get('purity', {})
    div = data.get('diversity', {})
    fc  = data.get('fc_sparsity', {})

    lines = [
        r"\begin{table}[t]",
        r"\caption{Prototype Quality Metrics.}",
        r"\label{tab:prototype_quality}",
        r"\begin{tabular}{lc}",
        r"\toprule",
        r"Metric & Value \\",
        r"\midrule",
        f"Mean push source-match similarity & {data.get('mean_source_match_sim',0):.3f} \\\\",
        f"Mean prototype purity & {pur.get('mean_purity',0):.3f} \\\\",
        f"Low-purity prototypes ($<$30\\%) & {pur.get('n_low_purity_lt30pct','—')}/190 \\\\",
        f"Intra-class distance & {div.get('mean_intra_class_distance',0):.3f} \\\\",
        f"Inter-class distance & {div.get('mean_inter_class_distance',0):.3f} \\\\",
        f"Separation ratio & {div.get('separation_ratio',0):.2f} \\\\",
        f"FC sparsity (Phase 4) & {fc.get('overall_sparsity_pct',0):.1f}\\% \\\\",
        r"\bottomrule", r"\end{tabular}", r"\end{table}",
    ]
    out_path = os.path.join(OUT_DIR, 'table_IX_prototype_quality.tex')
    with open(out_path, 'w') as f: f.write("\n".join(lines))
    print(f"  [Table IX] written to {out_path}")

# ════════════════════════════════════════════════════════════════════════════
# TABLE X — EFFICIENCY
# ════════════════════════════════════════════════════════════════════════════

def build_table_x():
    data = safe_load_json(PATHS['efficiency'])
    if not data:
        print("  [Table X] efficiency results not found — skipping")
        return

    lines = [
        r"\begin{table}[t]",
        r"\caption{Computational Efficiency Comparison.}",
        r"\label{tab:efficiency}",
        r"\begin{tabular}{lcccc}",
        r"\toprule",
        r"Model & Params (M) & GFLOPs & Latency@1 (ms) & Mem.\ (MB) \\",
        r"\midrule",
    ]
    for name, r in data.items():
        lat = r.get('latency',{}).get('batch_1',{}).get('mean_ms','—')
        lat_str = f"{lat:.2f}" if isinstance(lat, float) else lat
        lines.append(
            f"{name} & {r.get('params_total_M','—')} & "
            f"{r.get('gflops_batch1','—')} & {lat_str} & "
            f"{r.get('peak_memory_mb','—')} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]

    out_path = os.path.join(OUT_DIR, 'table_X_efficiency.tex')
    with open(out_path, 'w') as f: f.write("\n".join(lines))
    print(f"  [Table X] written to {out_path}")

# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    status = check_completeness()

    print("\n" + "="*70)
    print("GENERATING LATEX TABLES")
    print("="*70)
    build_table_iv()
    build_table_v()
    build_table_vi()
    build_table_vii()
    build_table_viii()
    build_table_ix()
    build_table_x()

    # Master manifest — every raw result, for supplementary material
    manifest = {k: (safe_load_json(p) if p.endswith('.json')
                    else (safe_load_csv(p).to_dict() if p.endswith('.csv')
                          and safe_load_csv(p) is not None else None))
                for k, p in PATHS.items()}
    manifest_path = os.path.join(OUT_DIR, 'all_results_manifest.json')
    with open(manifest_path, 'w') as f:
        json.dump(manifest, f, indent=2, default=str)

    print(f"\n{'='*70}")
    print(f"All tables written to: {OUT_DIR}")
    print(f"Master manifest:       {manifest_path}")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
