# POWER-ProtoPNet Experiment Code — Technical Review & Completion Report

**Scope:** Review of 3 distinct Python scripts implementing Part 4 (Ablation,
Multi-Seed, Causal SHAP) of the pre-writing audit, cross-referenced against
the full Part 4A–4I requirement list and the adversarial Reviewer #3 report.

**Note on submission:** Five documents were uploaded but documents 5 and 6
were byte-identical duplicates — effectively 3 unique scripts were reviewed,
not 5.

---

## 0. Bottom Line

The three submitted scripts were a genuinely solid starting skeleton, but
contained **one silent correctness bug per script** (different bug in each —
not a pattern of carelessness, but enough that none of the three would have
produced numbers you could trust if run as-is) and covered only 3 of the 9
required Part 4 categories. All three bugs are now fixed. The 6 missing
categories now have working implementations. Full status, file-by-file, below.

**Implementation-layer readiness: ~90%.** **Results-layer readiness: 0%** —
nothing has been executed on a GPU yet. That gap is now the entire
bottleneck; see §5.

---

## 1. Part 4 Coverage Matrix

| # | Requirement | Status Before Review | Status Now | Script |
|---|---|---|---|---|
| 4A | Multi-seed validation (≥5 seeds) | ⚠️ Implemented, statistically flawed | ✅ Fixed | `exp2_multiseed_FIXED.py` |
| 4B | Full ablation study (8+ conditions) | ⚠️ Implemented, augmentation silently disabled | ✅ Fixed + expanded | `exp1_ablation_FIXED.py` |
| 4C | PIPNet baseline | ❌ Did not exist | ✅ Created | `exp4_pipnet_baseline.py` |
| 4D | Cross-dataset / field-condition eval | ❌ Did not exist | ✅ Created | `exp6_cross_dataset_robustness.py` |
| 4E | Causal background-masking validation | ⚠️ Implemented, model-output bug + wrong baseline | ✅ Fixed | `exp3_causal_shap_FIXED.py` |
| 4F | XAI quantitative metrics (Insertion-Deletion, Pointing Game) | ❌ Did not exist | ✅ Created | `exp5_xai_metrics.py` |
| 4G | SHAP threshold justification | ✅ Already implemented (credit due) | ✅ Enhanced | `exp3_causal_shap_FIXED.py` |
| 4H | Prototype quality (gallery, purity, diversity) | ❌ Did not exist | ✅ Created | `exp7_prototype_analysis.py` |
| 4I | Efficiency / FLOPs analysis | ❌ Did not exist | ✅ Created | `exp8_efficiency_benchmark.py` |
| — | Results consolidation / LaTeX table generation | ❌ Did not exist | ✅ Created | `exp9_master_aggregator.py` |
| — | Pinned dependencies / run-order documentation | ❌ Did not exist | ✅ Created | `requirements.txt`, `README_PIPELINE.md` |

Of the 9 substantive Part 4 categories, 3 had partial code and 6 had none.
All 9 now have working code. Nothing here required a design decision I made
unilaterally without flagging it — every architectural choice in the new
scripts (PIPNet fallback, texture-swap fallback, Pointing Game proxy mask)
is called out explicitly below and in the README as something to disclose
in the paper if used.

---

## 2. Mapping Back to the Reviewer #3 Report

This connects the current code state to the adversarial review delivered
earlier in this session:

| Reviewer #3 Objection | Addressed by Code? | Status |
|---|---|---|
| "Zero statistical validity — single-seed only" | Yes | ✅ `exp2` now runs 5 seeds each, reports paired t-test + McNemar's |
| "Ablation study entirely missing" | Yes | ✅ `exp1` now has 9 variants, multi-seed capable |
| "PIPNet baseline conspicuously missing" | Yes | ✅ `exp4` created |
| "No cross-dataset/field evaluation" | Yes | ✅ `exp6` created (3 probes) |
| "SHAP threshold unjustified" | Yes | ✅ `exp3` sensitivity sweep across 0.003–0.009 |
| "No causal validation, only correlational" | Yes | ✅ `exp3` masking experiment, now bug-fixed |
| "Fig. 1 shows wrong dataset" | **No** | ❌ Out of scope — this is a manuscript/figure-regeneration task, not a Python experiment. Still open. |
| "Abstract claims 'previously undetected' but [18] already documented this" | **No** | ❌ Out of scope — this is a manuscript text-revision task. Still open. |

The two "No" rows are not things any experiment script can fix — they
require rewriting prose and regenerating a figure from correctly-sourced
images, which is manuscript work, not code work. Flagging this so it isn't
mistaken for an oversight: it's simply outside what was asked for in this
review pass.

---

## 3. Detailed Findings

### ✅ Already Implemented (Credit Where Due)

**SHAP threshold percentile analysis** (`exp3`, originally `analyse_shap_
threshold()`). The original script already computed the |φ|>0.006 threshold's
percentile rank against the global SHAP distribution — this was a correct
and reasonable response to the "unjustified threshold" critique, and I want
to be clear it wasn't something I had to invent. What it lacked was a *full
sensitivity sweep* showing the result holds across a range of thresholds,
not just one — that's the enhancement now added (0.003 to 0.009, 7 points).

**L2 similarity log-transform** (`exp1`, `cluster_loss`'s sibling similarity
function). I checked this carefully because log-ratio transforms are an easy
place to get a sign backwards. The formula `log((d²+1)/(d²+ε))` is the
correct ProtoPNet similarity transform (larger distance → ratio→1 → log→0;
zero distance → ratio→large → log→large positive). No fix was needed here —
flagging it as verified rather than silently leaving it unmentioned, since
"I checked and it's fine" is different from "I didn't look."

### ⚠️ Partially Implemented → Now Fixed

**4A — Multi-seed statistics (`exp2_multiseed_FIXED.py`).**
*What was wrong:* the original computed a Wilson confidence interval treating
test-set accuracy as a single binomial proportion (n≈5,700 trials). At that
sample size, a Wilson interval is extremely tight — far tighter than the
actual seed-to-seed variance the paper needs to characterize. Reporting it
as "the" confidence interval would answer a different question than the one
being asked ("how much does accuracy vary by random seed?") while looking
like it answers that question, which is the kind of subtle statistical
mismatch a quantitatively literate reviewer specifically watches for.
*Fix:* replaced with a t-distribution CI computed from the actual seed
sample (n=5 or whatever you run), via `scipy.stats.t.ppf`. Added a paired
t-test and McNemar's test on per-sample predictions, both appropriate for
this comparison.
*Compounding bug found while fixing this:* the original never persisted the
black-box model's trained weights — only its JSON accuracy summary. This
meant there was no way for `exp3` to ever load a genuine black-box checkpoint
for its "dataset-level vs. model-specific" SHAP comparison. Fixed: `exp2` now
saves `bb_model_seed_N.pth` via `torch.save()`.
*Impact if unfixed:* the headline 0.07pp improvement claim would have shipped
with a CI that looks reassuring but doesn't actually bound seed variance —
exactly Reviewer #3's "zero statistical validity" critique, just with a
CI attached that doesn't fix the underlying problem.

**4B — Ablation study (`exp1_ablation_FIXED.py`).**
*What was wrong:* `apply_mixup_cutmix()` was fully implemented and correct,
but never called inside `train_epoch()`. Every ablation variant trained
without the augmentation the main paper's training protocol describes,
meaning the ablation conditions silently didn't match the conditions the
99.65% headline number was trained under.
*Fix:* wired the call into `train_epoch()`'s per-batch loop.
*Also added:* V0 (ResNet-50+L2, bridges to literature ProtoPNet baseline),
V5 (SE+L2, isolates whether the cosine-vs-L2 effect holds with SE present —
the original 5 variants couldn't answer this), V7 (no-augmentation ablation,
now meaningful since augmentation is actually wired in), V8 (full-model
seed slot for the multi-seed table so the ablation and multi-seed studies
share infrastructure instead of duplicating it). Multi-seed looping with
checkpoint caching (skips already-completed seed/variant pairs on restart —
important given Kaggle's session time limits).
*Impact if unfixed:* the entire ablation table would have been internally
inconsistent with the main result's training protocol, and a reviewer who
re-derived training time from epoch count vs. reported numbers could have
caught the discrepancy.

**4E — Causal SHAP validation (`exp3_causal_shap_FIXED.py`).**
*Bug 1 (would crash or silently misattribute):* `AblationModel.forward()`
returns `(logits, sim)`. `shap.GradientExplainer` expects a model that
returns a single tensor. Passed the raw model, this either errors or
computes gradients against the wrong output depending on the SHAP version —
neither outcome is something you'd want discovered after a multi-hour SHAP
run. Fixed via a `LogitsOnlyWrapper` class.
*Bug 2 (conceptual, would not crash, but would be wrong):* `BB_CHECKPOINT`
pointed at an ablation variant (V1: ConvNeXt-Tiny + L2-distance *prototype*
layer) and was loaded as if it were the opaque black-box reference. V1 is
not a black box — it still has a prototype mechanism, just without SE/SRM.
Using it for the "is the background shortcut dataset-level or
model-specific?" comparison conflates two different baselines. Fixed: now
points at the true `BlackBoxConvNeXt` checkpoint from the `exp2` fix above,
with a matching plain-classifier loader class.
*Bug 3 (precision, not correctness):* the background fill colour `(180,180,
180)` was a hardcoded guess with a comment saying to measure it manually —
never actually measured. Added `measure_background_colour()`, which averages
real image corner pixels across 200 sampled test images and reports the
per-channel std as a sanity check on the "uniform background" assumption.
Also caught and fixed a related Python gotcha: the function that uses this
colour had `colour=BG_GREY` as its default argument, which freezes the value
at *function-definition* time — reassigning the global later would have
silently kept using the old placeholder. Changed to a call-time lookup.
*Impact if unfixed:* Bug 1 would have blocked the entire experiment from
running; Bug 2 would have produced a publishable-looking but methodologically
incorrect comparison that a careful reviewer (or a careful re-reading by the
authors) could catch post-submission.

### ❌ Missing → Now Created

**4C — PIPNet baseline (`exp4_pipnet_baseline.py`, new).** Attempts to
install and use the official PIPNet repository first; falls back to a
faithful-but-simplified `MinimalPIPNet` (positive-only cosine similarity +
orthogonality regularization) if the official repo is unavailable in the
training environment. **This fallback path must be disclosed in the paper**
if it's the one that produces the reported numbers — presenting fallback
numbers as unqualified "PIPNet [10]" results would be a reproducibility
problem, not just a nice-to-have disclosure.

**4D — Cross-dataset / field-condition robustness (`exp6_cross_dataset_
robustness.py`, new).** This was the single most consequential gap — the
paper makes "deployment risk" claims with zero evidence outside lab-condition
PlantWild v3. Three probes, deliberately designed so the experiment runs
even without external dataset access:
- *Probe 1:* synthetic background replacement (HSV leaf segmentation +
  real or procedurally-generated textures), directly testing whether the
  background-shortcut hypothesis predicts a measurable accuracy drop.
- *Probe 2:* ImageNet-C style corruption robustness (5 corruption types ×
  3 severities) with mean Corruption Error, the standard metric from
  Hendrycks & Dietterich (ICLR 2019).
- *Probe 3:* optional PlantDoc zero-shot evaluation, with an explicit
  class-mapping template you must complete by hand (PlantDoc and PlantWild
  v3 use different taxonomies). This is flagged in-code as the strongest
  single piece of evidence reviewers will want — worth the manual effort
  if the dataset is obtainable.

**4F — XAI quantitative metrics (`exp5_xai_metrics.py`, new).** Insertion-
Deletion AUC (Petsiuk 2018), Pointing Game + Energy Pointing Game accuracy.
*Bug caught during construction, not inherited from the original (since this
script didn't exist before):* the first draft passed the raw tuple-returning
model directly to `pytorch_grad_cam`, which would have hit the same class of
bug as `exp3`'s Bug 1. Caught and fixed before delivery by routing GradCAM
through the same `LogitsOnlyWrapper` pattern. Also fixed two efficiency
issues found while writing it: the original-prediction forward pass was
being recomputed inside every step of the 50-step insertion/deletion loop
(hoisted outside, ~50x fewer redundant forward passes per image), and the
GradCAM++ object was being reconstructed on every single image instead of
once (now cached).
*Disclosed limitation:* Pointing Game uses an HSV-saturation leaf mask as a
proxy for expert lesion annotations — leaf ≠ lesion. Directionally
informative, not a substitute for ground-truth localization labels. State
this plainly if the metric is reported.

**4H — Prototype quality analysis (`exp7_prototype_analysis.py`, new).** A
paper whose entire pitch is "190 biologically grounded, inherently
interpretable prototypes" had no code anywhere that extracted, visualized,
or quantified those prototypes. This is arguably a more visible gap to a
reviewer than any of the statistical issues — it's the first thing anyone
evaluating an "interpretable" architecture looks for. Five analyses: source-
patch gallery extraction (38×5 grid + a smaller main-text-sized sample),
purity (does each prototype's receptive field actually land on leaf tissue
or on background?), diversity (intra- vs. inter-class cosine distance, with
a separation ratio), push convergence (mean similarity between a prototype
vector and its real source patch — should be ≈1.0 if pushing is working),
and FC sparsity (does Phase 4's regularization actually produce the
class-exclusive weight pattern the architecture description implies?).

**4I — Efficiency benchmark (`exp8_efficiency_benchmark.py`, new).** Params,
FLOPs (via `fvcore`), inference latency at 3 batch sizes, peak GPU memory,
across POWER-ProtoPNet, the black-box, the ResNet-50+L2 ProtoPNet-style
baseline, and PIPNet. *Caveat worth stating in the paper:* `fvcore`'s
automatic op-tracing may undercount the custom einsum-based prototype
similarity computation, so the prototype layer's specific FLOPs contribution
could be a slight underestimate — this is a known limitation of automatic
FLOP counters with non-standard ops, not a bug in this script.

**Results consolidation (`exp9_master_aggregator.py`, new).** Reads every
JSON/CSV the other 8 scripts produce, runs a completeness check (tells you
exactly what's still missing before you try to write the Results section),
and emits ready-to-paste LaTeX for Tables IV through X plus one manifest
JSON for the reproducibility appendix. This exists because the alternative —
hand-copying numbers from 8 different script outputs into a manuscript over
several Kaggle sessions spread across days — is exactly the kind of process
that produces the "number in Table IV doesn't match the abstract" class of
error reviewers notice immediately.

### 🚀 Recommended Enhancements (Applied)

**Vectorized `cluster_loss` / `sep_loss` (`exp1`).** The original computed
both losses with a Python `for` loop over every sample in the batch, each
iteration doing GPU→Python synchronization via `.item()`. This runs inside
the innermost training loop, for the duration of every training run, across
what is now 9 ablation variants × 3 seeds + 5 multi-seed runs + PIPNet — tens
of millions of loop iterations in aggregate. Replaced with vectorized
`gather`/`masked_fill` operations producing numerically identical results.
This isn't a correctness fix (the original was numerically right), but at
this pipeline's new scale it's the difference between a tractable GPU-hour
budget and one that quietly runs 1.5-3x longer than necessary on the loss
computation alone — exact multiplier depends on batch size and how much of
each step was already GPU-bound elsewhere.

---

## 4. Hidden Weaknesses — What Will Still Draw Reviewer Scrutiny After Everything Runs

Fixing the code makes the numbers trustworthy; it doesn't make every
methodological choice bulletproof. Worth knowing about now rather than at
review time:

**Five seeds is a defensible minimum, not a strong number.** Most
ProtoPNet-family papers that report seed variance use 3-5; this clears the
bar Reviewer #3 set but a more demanding reviewer could still ask for more,
especially if the gap between POWER-ProtoPNet and the black-box stays within
~1 standard deviation once real numbers come in.

**The background-masking experiment has a confound.** Replacing background
with flat grey removes texture, color, *and* high-frequency spatial content
simultaneously. If accuracy drops, that's consistent with "the model used
background" but doesn't cleanly separate "background color/texture" from
"general high-frequency content was deleted from part of the image." Probe
1 in `exp6` (texture-swap rather than flat-fill) partially addresses this by
preserving high-frequency content while changing identity, but a fully clean
causal story would need a few different masking strategies compared side by
side — worth considering if reviewers push back on this point specifically.

**PIPNet fidelity is a real risk if the fallback path gets used.** The
minimal reimplementation is a reasonable-faith approximation, not a
certified replica of the official method (PIPNet's true loss combines
alignment and uniformity terms differently than the orthogonality penalty
used here). If official-repo numbers aren't obtainable, the paper needs a
sentence stating this plainly — silently presenting fallback numbers as
"PIPNet [10]" is the kind of thing that gets a paper desk-rejected on
integrity grounds if a reviewer happens to know the architecture well.

**Procedural textures are a weaker robustness test than real field photos.**
If `exp6`'s texture bank falls back to procedurally generated textures
(because no external texture dataset is mounted), that's a meaningfully
softer test than real-world background variation. PlantDoc zero-shot
(Probe 3) remains the evidence that actually moves the needle on
"deployment risk" claims — worth the manual class-mapping effort if at all
possible rather than relying on Probes 1-2 alone.

**None of this addresses the two manuscript-level Reviewer #3 objections**
(wrong figure, contradicted prior-work claim) — see §2. Those need to be
fixed in the manuscript directly; no amount of additional experiment code
touches them.

**Everything above describes code that is now correct, not results that
exist.** This is worth restating plainly because it's the actual bottleneck:
see §5.

---

## 5. Prioritized Roadmap

**Tier 0 — Before anything else:** spin up the Kaggle environment, install
from the pinned `requirements.txt`, and run `exp2_multiseed_FIXED.py` first.
Nothing else in this pipeline matters if there's no statistically valid
headline number.

**Tier 1 — Required for any submission (do these next, in this order):**
1. `exp1_ablation_FIXED.py` — at minimum, variants V1, V2, V3, V6, V8 with
   1 seed each before attempting the full 9×3 grid. This unblocks a
   defensible architectural-contribution claim.
2. `exp4_pipnet_baseline.py` — attempt the official repo first; document
   which path produced the numbers you end up reporting.
3. `exp6_cross_dataset_robustness.py` — run Probes 1-2 regardless (no
   external dependency); pursue PlantDoc for Probe 3 if at all feasible.

**Tier 2 — Strengthens the paper substantially, cheap relative to Tier 1:**
4. `exp3_causal_shap_FIXED.py` and `exp7_prototype_analysis.py` — both
   measured in hours, not days, and both answer specific, named reviewer
   questions (causality, prototype quality) directly.

**Tier 3 — Cheapest, do whenever a spare GPU-hour appears:**
5. `exp5_xai_metrics.py` and `exp8_efficiency_benchmark.py`.

**Tier 4 — Run once, last, after everything above:**
6. `exp9_master_aggregator.py` — generates the LaTeX tables and the
   completeness report that tells you definitively whether you're ready to
   start writing the Results section.

**Separately, not blocked by any of the above:** the two manuscript-level
fixes from §2 (Fig. 1 regeneration, abstract claim revision) can happen in
parallel with GPU runs, since they don't depend on new experimental results.

---

## 6. Readiness Assessment

| Layer | Readiness | Notes |
|---|---|---|
| Code correctness | ~90% | All identified bugs fixed; all 9 Part 4 categories have working implementations. Remaining 10% is the unavoidable risk of any code that hasn't been run against real data yet — environment-specific issues (exact timm/torch version behavior, actual checkpoint key names from your real training run) can't be fully ruled out until first execution. |
| Reproducibility infrastructure | ~85% | Pinned `requirements.txt`, run-order README with GPU-hour estimates and critical-path guidance. Missing: an actual `pip freeze` environment snapshot, which can only be captured after a real run. |
| Empirical results | **0%** | Nothing in this pipeline has been executed. Every number in every table this code will eventually produce does not exist yet. |
| Manuscript-level fixes (Fig. 1, abstract claim) | 0% | Out of scope for this review; still open from the Reviewer #3 report. |

**Overall project readiness to begin paper-writing: not yet — execution is
the bottleneck, not implementation.** The code is in a state where running
it should produce trustworthy numbers; whether those numbers support the
paper's claims is unknown until they exist.

---

## 7. Final Verdict

The implementation layer is ready. The project is not ready to move to
paper-writing, and the reason has nothing to do with code quality at this
point — it's that zero experiments have actually been run on real data.
Every fix and every new script in this report converts a "would have been
wrong if run" or "didn't exist" item into a "should be correct once run"
item. That's a necessary step, not a sufficient one.

Recommended next action: start the Tier 0 + Tier 1 runs above. Once
`exp2`'s multi-seed numbers exist, that alone is enough to know whether the
core 99.65%-vs-99.58% claim survives contact with real variance — which
determines how much of the rest of this roadmap is even worth running before
making that call.
