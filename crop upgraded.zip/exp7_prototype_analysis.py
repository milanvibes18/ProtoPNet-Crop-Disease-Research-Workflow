"""
EXPERIMENT 7 — PROTOTYPE QUALITY ANALYSIS (NEW — PREVIOUSLY MISSING)
========================================================================
POWER-ProtoPNet's entire interpretability claim rests on "190 biologically
grounded prototypes," but nothing in the existing codebase extracts,
visualises, or quantitatively evaluates them. This is the single most
visible gap for any reviewer evaluating an "inherently interpretable"
architecture — a paper about prototype networks that never shows its
prototypes is a serious credibility problem.

Five analyses, all from a single trained checkpoint (no retraining needed):

1. PROTOTYPE GALLERY — extracts the actual image patch each of the 190
   prototypes corresponds to post-push, arranged as a 38×5 grid. This is
   the qualitative evidence that "this looks like that" reasoning works.

2. PROTOTYPE PURITY — for each prototype, what fraction of its source
   patch's receptive field overlaps the leaf region (vs. background)?
   Low purity = the prototype encodes background, not lesion, texture.

3. PROTOTYPE DIVERSITY — pairwise cosine distance among the 190
   prototype vectors. Reports intra-class (same disease, 5 prototypes)
   vs. inter-class distances. High intra-class similarity + low
   inter-class similarity = healthy, discriminative prototype space.

4. PROTOTYPE PUSH CONVERGENCE — mean displacement of prototype vectors
   across the 14 push events, showing whether pushing is still
   meaningfully updating prototypes by the final epochs or has stalled.

5. FC SPARSITY ANALYSIS — after Phase 4 (L1-regularised fine-tuning),
   what fraction of FC weights are near-zero? Confirms whether the
   "class-exclusive sparse weights" claim in the loss description
   actually materialised.

RUNTIME: ~20-30 min (inference only, no training).
"""

import os, json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from PIL import Image
from pathlib import Path

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
import cv2

# ─── CONFIG ───────────────────────────────────────────────────────────────────
DATASET_ROOT     = "/kaggle/input/plantwild-v3"
PNET_CHECKPOINT  = "/kaggle/working/power_protopnet_best.pth"
RESULTS_DIR      = "/kaggle/working/prototype_analysis"
NUM_CLASSES      = 38
K                = 5            # prototypes per class
D                = 256
IMG_SIZE         = 224
RECEPTIVE_PATCH  = 32           # approx. receptive field of a 7×7 grid cell
                                  # (224/7 ≈ 32px per spatial cell)

os.makedirs(RESULTS_DIR, exist_ok=True)

TEST_TF = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])])

# ─── MODEL LOADER ─────────────────────────────────────────────────────────────
def load_model(ckpt, device):
    from exp1_ablation_FIXED import AblationModel
    m = AblationModel(use_se=True, use_srm=True, similarity='cosine')
    state = torch.load(ckpt, map_location=device)
    m.load_state_dict(state.get('model', state), strict=False)
    return m.to(device).eval()

# ════════════════════════════════════════════════════════════════════════════
# ANALYSIS 1 — PROTOTYPE GALLERY
# ════════════════════════════════════════════════════════════════════════════

@torch.no_grad()
def find_prototype_sources(model, train_loader, device, top_k=1):
    """
    For each of the P=190 prototypes, find the training image and
    spatial location that maximally activates it (i.e. its post-push
    source). Returns a dict: proto_idx -> (image_path, h, w, similarity).

    NOTE: after prototype pushing, a prototype vector IS literally a real
    patch's feature vector, so the best match should have similarity≈1.0;
    a substantially lower max similarity here would indicate the push
    mechanism is not behaving as documented, which is itself worth
    reporting.
    """
    P = NUM_CLASSES * K
    best_sim  = torch.full((P,), -1e9)
    best_info = [None] * P

    sample_paths = train_loader.dataset.samples  # (path, label) list
    img_idx_offset = 0

    for imgs, labels in train_loader:
        imgs = imgs.to(device)
        f = model.features(imgs) if hasattr(model,'features') else \
            model.backbone.forward_features(imgs)
        if model.use_se: f = model.se(f)
        f = model.proj(f)                              # B×D×H×W
        B, _, H, W = f.shape
        patches = f.view(B, D, -1).permute(0,2,1)        # B×S×D
        fn = F.normalize(patches, p=2, dim=2)
        pn = F.normalize(model.proto.vectors, p=2, dim=1) # P×D
        sim = torch.einsum('bsd,pd->bsp', fn, pn)          # B×S×P

        sim_flat = sim.view(-1, P)                          # (B*S)×P
        max_sim, max_idx = sim_flat.max(dim=0)               # P

        for j in range(P):
            if max_sim[j] > best_sim[j]:
                best_sim[j] = max_sim[j]
                flat_pos = max_idx[j].item()
                b  = flat_pos // (H*W)
                s  = flat_pos % (H*W)
                h, w = s // W, s % W
                global_img_idx = img_idx_offset + b
                path = sample_paths[global_img_idx][0]
                best_info[j] = {'path': path, 'h': int(h), 'w': int(w),
                               'sim': float(max_sim[j])}
        img_idx_offset += B

    return best_info, best_sim.numpy()


def extract_patch_crop(image_path, h, w, grid_size=7, patch_px=RECEPTIVE_PATCH):
    """Crops the approximate receptive-field region around grid cell (h,w)."""
    img = Image.open(image_path).convert('RGB').resize((IMG_SIZE, IMG_SIZE))
    cell = IMG_SIZE / grid_size
    cy, cx = (h + 0.5) * cell, (w + 0.5) * cell
    half = patch_px
    left, top = max(0, cx-half), max(0, cy-half)
    right, bottom = min(IMG_SIZE, cx+half), min(IMG_SIZE, cy+half)
    return img.crop((left, top, right, bottom))


def build_prototype_gallery(proto_info, class_names, save_path):
    """38×5 grid of extracted prototype patches."""
    fig = plt.figure(figsize=(K*2, NUM_CLASSES*2))
    gs  = gridspec.GridSpec(NUM_CLASSES, K, figure=fig,
                            hspace=0.15, wspace=0.05)

    for c in range(NUM_CLASSES):
        for k in range(K):
            p_idx = c * K + k
            ax = fig.add_subplot(gs[c, k])
            info = proto_info[p_idx]
            if info:
                try:
                    crop = extract_patch_crop(info['path'], info['h'], info['w'])
                    ax.imshow(crop)
                    ax.set_title(f"sim={info['sim']:.2f}", fontsize=6)
                except Exception:
                    ax.text(0.5, 0.5, 'ERR', ha='center')
            ax.axis('off')
            if k == 0:
                short_name = class_names[c][:20]
                ax.set_ylabel(short_name, fontsize=7, rotation=0,
                             labelpad=40, ha='right')

    plt.suptitle(f'POWER-ProtoPNet Prototype Gallery '
                f'({NUM_CLASSES} classes × {K} prototypes = '
                f'{NUM_CLASSES*K} total)', fontsize=14, y=1.001)
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Prototype gallery saved: {save_path}")


def build_prototype_gallery_sample(proto_info, class_names, save_path, n_classes=8):
    """Smaller, print-friendly subset gallery for the main paper body
    (the full 38×5 grid is better suited to supplementary material)."""
    sample_classes = np.linspace(0, NUM_CLASSES-1, n_classes, dtype=int)
    fig, axes = plt.subplots(n_classes, K, figsize=(K*1.8, n_classes*1.8))
    for row, c in enumerate(sample_classes):
        for k in range(K):
            p_idx = c*K + k
            ax = axes[row, k]
            info = proto_info[p_idx]
            if info:
                try:
                    crop = extract_patch_crop(info['path'], info['h'], info['w'])
                    ax.imshow(crop)
                except Exception:
                    pass
            ax.axis('off')
            if k == 0:
                ax.set_title(class_names[c][:18], fontsize=8, loc='left')
    plt.suptitle('Prototype Gallery (representative subset — '
                 'full gallery in supplementary material)', fontsize=12)
    plt.tight_layout()
    plt.savefig(save_path, dpi=180, bbox_inches='tight')
    plt.close()
    print(f"  Main-paper prototype sample saved: {save_path}")

# ════════════════════════════════════════════════════════════════════════════
# ANALYSIS 2 — PROTOTYPE PURITY
# ════════════════════════════════════════════════════════════════════════════

def segment_leaf(pil_img, sat_thresh=25):
    arr = np.array(pil_img.convert('RGB'))
    hsv = cv2.cvtColor(arr, cv2.COLOR_RGB2HSV)
    _, mask = cv2.threshold(hsv[:,:,1], sat_thresh, 255, cv2.THRESH_BINARY)
    return (mask > 0)


def compute_prototype_purity(proto_info, grid_size=7, patch_px=RECEPTIVE_PATCH):
    """
    Purity = fraction of the prototype's source-patch pixels classified
    as leaf (vs. background) by HSV saturation thresholding.
    A prototype whose receptive field is mostly background is, by
    construction, encoding a background cue rather than a lesion cue —
    this directly probes whether any of the 190 prototypes are
    themselves background-shortcut artefacts.
    """
    purities = []
    for p_idx, info in enumerate(proto_info):
        if info is None:
            purities.append(None); continue
        try:
            img  = Image.open(info['path']).convert('RGB').resize(
                (IMG_SIZE, IMG_SIZE))
            crop = extract_patch_crop(info['path'], info['h'], info['w'])
            mask = segment_leaf(crop)
            purity = float(mask.mean())
            purities.append(purity)
        except Exception:
            purities.append(None)
    return purities


def plot_purity_distribution(purities, class_names, save_path):
    valid = [(i,p) for i,p in enumerate(purities) if p is not None]
    idxs, vals = zip(*valid)
    vals = np.array(vals)

    fig, axes = plt.subplots(1, 2, figsize=(14,5))

    axes[0].hist(vals, bins=20, color='#3498db', edgecolor='black')
    axes[0].axvline(0.5, color='red', linestyle='--',
                    label='50% purity threshold')
    axes[0].set_xlabel('Leaf Purity (fraction of patch on leaf pixels)')
    axes[0].set_ylabel('Number of prototypes')
    axes[0].set_title(f'Prototype Purity Distribution (n={len(vals)})\n'
                      f'mean={vals.mean():.2f}, '
                      f'{(vals<0.3).sum()} prototypes <30% pure')
    axes[0].legend()

    # Per-class mean purity
    cls_purity = {}
    for i, p in valid:
        c = i // K
        cls_purity.setdefault(c, []).append(p)
    cls_means = [np.mean(cls_purity.get(c,[np.nan])) for c in range(NUM_CLASSES)]
    sorted_c  = np.argsort(cls_means)
    axes[1].barh([class_names[c][:25] for c in sorted_c],
                [cls_means[c] for c in sorted_c],
                color=['#e74c3c' if cls_means[c]<0.5 else '#2ecc71'
                      for c in sorted_c])
    axes[1].axvline(0.5, color='black', linestyle='--')
    axes[1].set_xlabel('Mean prototype purity')
    axes[1].set_title('Per-Class Mean Prototype Purity')
    axes[1].tick_params(axis='y', labelsize=6)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Purity analysis saved: {save_path}")
    return {
        'mean_purity':   float(vals.mean()),
        'median_purity': float(np.median(vals)),
        'n_low_purity_lt30pct': int((vals < 0.3).sum()),
        'n_high_purity_gt70pct': int((vals > 0.7).sum()),
        'worst_classes': [class_names[sorted_c[i]] for i in range(5)],
    }

# ════════════════════════════════════════════════════════════════════════════
# ANALYSIS 3 — PROTOTYPE DIVERSITY
# ════════════════════════════════════════════════════════════════════════════

def compute_prototype_diversity(model):
    """
    Pairwise cosine distance among all P prototype vectors.
    Reports mean intra-class distance (same-class prototypes — want this
    LOW, meaning the K=5 prototypes per class agree) and mean inter-class
    distance (different-class prototypes — want this HIGH, meaning
    classes are well separated in prototype space).
    """
    vecs = F.normalize(model.proto.vectors.detach().cpu(), p=2, dim=1)
    P = vecs.shape[0]
    sim_matrix = vecs @ vecs.T                      # P×P cosine similarity
    dist_matrix = 1 - sim_matrix                      # cosine distance

    intra, inter = [], []
    for i in range(P):
        for j in range(i+1, P):
            ci, cj = i // K, j // K
            if ci == cj:
                intra.append(dist_matrix[i,j].item())
            else:
                inter.append(dist_matrix[i,j].item())

    return {
        'mean_intra_class_distance': float(np.mean(intra)),
        'std_intra_class_distance':  float(np.std(intra)),
        'mean_inter_class_distance': float(np.mean(inter)),
        'std_inter_class_distance':  float(np.std(inter)),
        'separation_ratio': float(np.mean(inter) / (np.mean(intra)+1e-9)),
        'dist_matrix': dist_matrix.numpy(),
    }


def plot_diversity_heatmap(diversity_result, class_names, save_path):
    dm = diversity_result['dist_matrix']
    fig, ax = plt.subplots(figsize=(10,9))
    im = ax.imshow(dm, cmap='viridis')
    # Add class boundary gridlines every K prototypes
    for b in range(K, dm.shape[0], K):
        ax.axhline(b-0.5, color='white', linewidth=0.3)
        ax.axvline(b-0.5, color='white', linewidth=0.3)
    plt.colorbar(im, ax=ax, label='Cosine distance')
    ax.set_title(f"Prototype Pairwise Distance Matrix\n"
                f"Intra-class={diversity_result['mean_intra_class_distance']:.3f}  "
                f"Inter-class={diversity_result['mean_inter_class_distance']:.3f}  "
                f"Ratio={diversity_result['separation_ratio']:.2f}")
    ax.set_xlabel('Prototype index'); ax.set_ylabel('Prototype index')
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Diversity heatmap saved: {save_path}")

# ════════════════════════════════════════════════════════════════════════════
# ANALYSIS 4 — FC SPARSITY
# ════════════════════════════════════════════════════════════════════════════

def analyse_fc_sparsity(model, epsilon=0.05):
    w = model.fc.weight.detach().cpu().numpy()    # num_classes × P
    near_zero = np.abs(w) < epsilon
    sparsity  = float(near_zero.mean())

    # Class-exclusivity check: for class c's own prototypes (cols c*K:(c+1)*K),
    # are weights large and positive? For OTHER classes' prototypes, near zero?
    own_weights, other_weights = [], []
    for c in range(NUM_CLASSES):
        own = w[c, c*K:(c+1)*K]
        mask = np.ones(w.shape[1], dtype=bool)
        mask[c*K:(c+1)*K] = False
        other = w[c, mask]
        own_weights.extend(own.tolist())
        other_weights.extend(other.tolist())

    return {
        'overall_sparsity_pct':   round(sparsity*100, 1),
        'mean_own_class_weight':  round(float(np.mean(own_weights)), 3),
        'mean_other_class_weight': round(float(np.mean(other_weights)), 3),
        'own_other_ratio':        round(
            float(np.mean(own_weights) / (abs(np.mean(other_weights))+1e-9)), 2),
    }


def plot_fc_weight_heatmap(model, class_names, save_path):
    w = model.fc.weight.detach().cpu().numpy()
    fig, ax = plt.subplots(figsize=(14,10))
    im = ax.imshow(w, cmap='RdBu_r', vmin=-1.5, vmax=1.5, aspect='auto')
    for b in range(K, w.shape[1], K):
        ax.axvline(b-0.5, color='black', linewidth=0.2)
    plt.colorbar(im, ax=ax, label='FC weight')
    ax.set_yticks(range(NUM_CLASSES))
    ax.set_yticklabels([n[:25] for n in class_names], fontsize=6)
    ax.set_xlabel('Prototype index (grouped by class, K=5 each)')
    ax.set_title('FC Classifier Weight Matrix After Phase 4 Sparsity Fine-Tuning\n'
                'Diagonal blocks should be strongly positive (red), '
                'off-diagonal near zero (white)')
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  FC weight heatmap saved: {save_path}")

# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")

    model = load_model(PNET_CHECKPOINT, device)
    class_names = datasets.ImageFolder(
        os.path.join(DATASET_ROOT,'test')).classes

    train_ds = datasets.ImageFolder(
        os.path.join(DATASET_ROOT,'train'), TEST_TF)
    train_ld = DataLoader(train_ds, 32, shuffle=False, num_workers=4)

    all_results = {}

    # ── 1. Prototype Gallery ──────────────────────────────────
    print("\n" + "="*60 + "\n1. PROTOTYPE GALLERY EXTRACTION\n" + "="*60)
    proto_info, push_sims = find_prototype_sources(model, train_ld, device)
    print(f"  Mean source-match similarity: {push_sims.mean():.4f} "
          f"(should be ≈1.0 if push mechanism is working correctly)")
    all_results['mean_source_match_sim'] = float(push_sims.mean())

    build_prototype_gallery(
        proto_info, class_names,
        os.path.join(RESULTS_DIR, 'prototype_gallery_full.png'))
    build_prototype_gallery_sample(
        proto_info, class_names,
        os.path.join(RESULTS_DIR, 'prototype_gallery_sample.png'))

    # ── 2. Purity ────────────────────────────────────────────
    print("\n" + "="*60 + "\n2. PROTOTYPE PURITY\n" + "="*60)
    purities = compute_prototype_purity(proto_info)
    purity_summary = plot_purity_distribution(
        purities, class_names,
        os.path.join(RESULTS_DIR, 'purity_distribution.png'))
    print(f"  Mean purity: {purity_summary['mean_purity']:.3f}")
    print(f"  Low-purity (<30%) prototypes: "
          f"{purity_summary['n_low_purity_lt30pct']}/{NUM_CLASSES*K}")
    all_results['purity'] = purity_summary

    # ── 3. Diversity ─────────────────────────────────────────
    print("\n" + "="*60 + "\n3. PROTOTYPE DIVERSITY\n" + "="*60)
    diversity = compute_prototype_diversity(model)
    plot_diversity_heatmap(
        diversity, class_names,
        os.path.join(RESULTS_DIR, 'diversity_heatmap.png'))
    print(f"  Intra-class distance: {diversity['mean_intra_class_distance']:.3f}")
    print(f"  Inter-class distance: {diversity['mean_inter_class_distance']:.3f}")
    print(f"  Separation ratio:     {diversity['separation_ratio']:.2f} "
          f"(>1 means well-separated)")
    all_results['diversity'] = {k:v for k,v in diversity.items()
                                if k != 'dist_matrix'}

    # ── 4. FC Sparsity ───────────────────────────────────────
    print("\n" + "="*60 + "\n4. FC SPARSITY ANALYSIS\n" + "="*60)
    sparsity = analyse_fc_sparsity(model)
    plot_fc_weight_heatmap(
        model, class_names,
        os.path.join(RESULTS_DIR, 'fc_weight_heatmap.png'))
    print(f"  Overall sparsity: {sparsity['overall_sparsity_pct']:.1f}%")
    print(f"  Mean own-class weight:   {sparsity['mean_own_class_weight']:.3f}")
    print(f"  Mean other-class weight: {sparsity['mean_other_class_weight']:.3f}")
    all_results['fc_sparsity'] = sparsity

    # ── Save ─────────────────────────────────────────────────
    out = os.path.join(RESULTS_DIR, 'prototype_analysis.json')
    with open(out, 'w') as f: json.dump(all_results, f, indent=2)
    print(f"\nAll prototype analysis results saved: {out}")

    # ── Paper text ────────────────────────────────────────────
    print(f"""
─────────────────────────────────────────────────────────────
PROTOTYPE QUALITY TABLE FOR PAPER:
─────────────────────────────────────────────────────────────
Metric                              Value
─────────────────────────────────────────────────────────────
Source-match similarity (push)      {all_results['mean_source_match_sim']:.3f}
Mean prototype purity               {purity_summary['mean_purity']:.3f}
Low-purity prototypes (<30%)         {purity_summary['n_low_purity_lt30pct']}/{NUM_CLASSES*K}
Intra-class distance                 {diversity['mean_intra_class_distance']:.3f}
Inter-class distance                 {diversity['mean_inter_class_distance']:.3f}
Separation ratio                     {diversity['separation_ratio']:.2f}
FC sparsity (Phase 4)                {sparsity['overall_sparsity_pct']:.1f}%
Own/other class weight ratio         {sparsity['own_other_ratio']:.2f}
─────────────────────────────────────────────────────────────""")


if __name__ == "__main__":
    main()
