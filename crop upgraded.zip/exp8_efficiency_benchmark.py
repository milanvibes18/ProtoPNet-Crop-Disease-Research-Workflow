"""
EXPERIMENT 8 — EFFICIENCY BENCHMARK (NEW)
=============================================
Computes parameter counts, FLOPs, inference latency, and peak GPU memory
for every model in the comparison table (POWER-ProtoPNet, black-box
ConvNeXt-Tiny, the ablation variants, and PIPNet). The original paper
reports parameter counts only; FLOPs and latency are absent, which
matters if any efficiency claim ("parameter-efficient SRM", "~8x param
saving") is going to be defended quantitatively rather than asserted.

RUNTIME: ~10 minutes (no training; single-batch forward passes).
"""

import os, json, time
import numpy as np
import torch
import torch.nn as nn

try:
    from fvcore.nn import FlopCountAnalysis, parameter_count
    HAS_FVCORE = True
except ImportError:
    os.system("pip install fvcore -q")
    from fvcore.nn import FlopCountAnalysis, parameter_count
    HAS_FVCORE = True

# ─── CONFIG ───────────────────────────────────────────────────────────────────
RESULTS_DIR  = "/kaggle/working/efficiency"
IMG_SIZE     = 224
BATCH_SIZES  = [1, 8, 32]     # latency measured at each
N_WARMUP     = 10
N_TIMED      = 50

os.makedirs(RESULTS_DIR, exist_ok=True)


def count_params(model):
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total, trainable


def count_flops(model, input_shape=(1, 3, IMG_SIZE, IMG_SIZE), device='cpu'):
    model.eval()
    dummy = torch.randn(*input_shape).to(device)
    try:
        flops = FlopCountAnalysis(model, dummy)
        flops.unsupported_ops_warnings(False)
        flops.uncalled_modules_warnings(False)
        return flops.total()
    except Exception as e:
        print(f"  FLOPs counting failed: {e}")
        return None


@torch.no_grad()
def measure_latency(model, batch_size, device, n_warmup=10, n_timed=50):
    model.eval()
    dummy = torch.randn(batch_size, 3, IMG_SIZE, IMG_SIZE).to(device)

    for _ in range(n_warmup):
        _ = model(dummy)
    if device.type == 'cuda':
        torch.cuda.synchronize()

    times = []
    for _ in range(n_timed):
        t0 = time.perf_counter()
        _ = model(dummy)
        if device.type == 'cuda':
            torch.cuda.synchronize()
        times.append(time.perf_counter() - t0)

    times = np.array(times) * 1000  # ms
    return {
        'mean_ms': float(times.mean()),
        'std_ms':  float(times.std()),
        'p50_ms':  float(np.percentile(times, 50)),
        'p95_ms':  float(np.percentile(times, 95)),
        'throughput_img_per_sec': float(batch_size / (times.mean()/1000)),
    }


def measure_peak_memory(model, batch_size, device):
    if device.type != 'cuda':
        return None
    torch.cuda.reset_peak_memory_stats(device)
    torch.cuda.empty_cache()
    dummy = torch.randn(batch_size, 3, IMG_SIZE, IMG_SIZE).to(device)
    with torch.no_grad():
        _ = model(dummy)
    torch.cuda.synchronize()
    peak_mb = torch.cuda.max_memory_allocated(device) / (1024**2)
    return float(peak_mb)


def benchmark_model(name, model, device):
    print(f"\n{'='*60}\nBenchmarking: {name}\n{'='*60}")
    model = model.to(device).eval()

    total_p, trainable_p = count_params(model)
    print(f"  Params: {total_p/1e6:.2f}M total, {trainable_p/1e6:.2f}M trainable")

    flops = count_flops(model, (1,3,IMG_SIZE,IMG_SIZE), device)
    gflops = flops/1e9 if flops else None
    if gflops:
        print(f"  FLOPs (batch=1): {gflops:.2f} GFLOPs")

    latencies = {}
    for bs in BATCH_SIZES:
        try:
            lat = measure_latency(model, bs, device, N_WARMUP, N_TIMED)
            latencies[f'batch_{bs}'] = lat
            print(f"  Batch={bs:3d}: {lat['mean_ms']:.2f}±{lat['std_ms']:.2f}ms  "
                  f"({lat['throughput_img_per_sec']:.1f} img/s)")
        except Exception as e:
            print(f"  Batch={bs}: FAILED ({e})")

    peak_mem = measure_peak_memory(model, max(BATCH_SIZES), device)
    if peak_mem:
        print(f"  Peak GPU memory (batch={max(BATCH_SIZES)}): {peak_mem:.1f} MB")

    return {
        'params_total_M':     round(total_p/1e6, 2),
        'params_trainable_M': round(trainable_p/1e6, 2),
        'gflops_batch1':       round(gflops, 2) if gflops else None,
        'latency':             latencies,
        'peak_memory_mb':      round(peak_mem,1) if peak_mem else None,
    }


def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")

    results = {}

    # ── POWER-ProtoPNet ───────────────────────────────────────
    try:
        from exp1_ablation_FIXED import AblationModel
        pnet = AblationModel(use_se=True, use_srm=True, similarity='cosine')
        results['POWER-ProtoPNet'] = benchmark_model('POWER-ProtoPNet', pnet, device)
    except Exception as e:
        print(f"Could not benchmark POWER-ProtoPNet: {e}")

    # ── Black-box ConvNeXt-Tiny ────────────────────────────────
    try:
        import timm
        class _Plain(nn.Module):
            def __init__(self):
                super().__init__()
                self.net = timm.create_model('convnext_tiny',
                                             pretrained=False, num_classes=38)
            def forward(self, x): return self.net(x)
        bb = _Plain()
        results['ConvNeXt-Tiny (BB)'] = benchmark_model(
            'ConvNeXt-Tiny (Black-Box)', bb, device)
    except Exception as e:
        print(f"Could not benchmark black-box: {e}")

    # ── Ablation V1 (ResNet-50 ProtoPNet style) ────────────────
    try:
        from exp1_ablation_FIXED import AblationModel as AM
        protopnet_style = AM(backbone='resnet50', use_se=False,
                             use_srm=False, similarity='l2')
        results['ProtoPNet-style (ResNet-50)'] = benchmark_model(
            'ProtoPNet-style (ResNet-50+L2)', protopnet_style, device)
    except Exception as e:
        print(f"Could not benchmark ProtoPNet-style: {e}")

    # ── PIPNet (minimal) ────────────────────────────────────────
    try:
        from exp4_pipnet_baseline import MinimalPIPNet
        pipnet = MinimalPIPNet(num_classes=38, K=10, D=256)
        results['PIPNet (minimal)'] = benchmark_model(
            'PIPNet (minimal reimpl.)', pipnet, device)
    except Exception as e:
        print(f"Could not benchmark PIPNet: {e}")

    # ── Save & Table ────────────────────────────────────────────
    out = os.path.join(RESULTS_DIR, 'efficiency_results.json')
    with open(out, 'w') as f: json.dump(results, f, indent=2)

    print(f"\n{'='*70}\nEFFICIENCY SUMMARY TABLE\n{'='*70}")
    print(f"{'Model':<30}{'Params(M)':>10}{'GFLOPs':>10}"
          f"{'Latency@1(ms)':>15}{'Mem(MB)':>10}")
    for name, r in results.items():
        lat1 = r['latency'].get('batch_1',{}).get('mean_ms','-')
        lat1_str = f"{lat1:.2f}" if isinstance(lat1,float) else lat1
        print(f"{name:<30}{r['params_total_M']:>10.2f}"
              f"{r['gflops_batch1'] or 0:>10.2f}"
              f"{lat1_str:>15}{r['peak_memory_mb'] or 0:>10.1f}")

    print(f"\nSaved: {out}")


if __name__ == "__main__":
    main()
