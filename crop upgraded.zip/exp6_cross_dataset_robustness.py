"""
EXPERIMENT 6 — CROSS-DATASET / FIELD-CONDITION ROBUSTNESS (NEW)
===================================================================
This is the single most important missing experiment identified in the
pre-writing audit (Part 4D, marked CRITICAL). The paper claims "deployment
risk" and "field-condition implications" but every existing experiment
runs exclusively on laboratory-condition PlantWild v3 images. Without
this script, those claims are unsupported speculation.

Three independent robustness probes are implemented, requiring NO
external dataset download (so it runs even if PlantDoc access is
unavailable on Kaggle), plus an optional PlantDoc hook if you do have it:

PROBE 1 — Synthetic Background Replacement
  Replaces the uniform grey lab background with randomly sampled
  real-world textures (grass, soil, wood, fabric) while leaving the leaf
  region untouched. Directly tests the "background shortcut" hypothesis:
  if POWER-ProtoPNet's accuracy degrades more than the black-box under
  background swap, the prototype mechanism is MORE background-dependent,
  not less.

PROBE 2 — ImageNet-C Style Corruption Robustness
  Applies 5 standard corruption types (Gaussian noise, defocus blur,
  brightness shift, contrast shift, JPEG compression) at 3 severities.
  Reports mean Corruption Error (mCE) relative to a reference model,
  the standard metric from Hendrycks & Dietterich (ICLR 2019).

PROBE 3 — PlantDoc Zero-Shot Evaluation (optional, requires download)
  If a PlantDoc-format directory is available, evaluates all trained
  models zero-shot (no fine-tuning) to measure real field-condition
  generalisation. Class names must be manually mapped (a mapping dict
  is provided as a template — PlantDoc and PlantWild v3 have different
  class taxonomies and only partially overlap).

RUNTIME: Probes 1-2 ~1.5h (inference only). Probe 3 depends on dataset size.
"""

import os, json, random
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import datasets, transforms
import cv2

# ─── CONFIG ───────────────────────────────────────────────────────────────────
DATASET_ROOT     = "/kaggle/input/plantwild-v3"
TEXTURE_DIR      = "/kaggle/input/dtd-textures"   # any natural-texture dataset; see NOTE below
PLANTDOC_ROOT    = "/kaggle/input/plantdoc"        # optional, set None if unavailable
PNET_CHECKPOINT  = "/kaggle/working/power_protopnet_best.pth"
BB_CHECKPOINT    = "/kaggle/working/multiseed/bb_model_seed_0.pth"
RESULTS_DIR      = "/kaggle/working/robustness"
NUM_CLASSES      = 38
IMG_SIZE         = 224
BATCH_SIZE       = 32

os.makedirs(RESULTS_DIR, exist_ok=True)

# NOTE on TEXTURE_DIR: any folder of natural images works (the script only
# crops random patches for use as background fill). Good free options on
# Kaggle: "Describable Textures Dataset (DTD)" or "Intel Image
# Classification" (forest/buildings/mountain categories make decent
# field-like backgrounds). If unavailable, the script falls back to
# procedurally generated textures (Perlin-noise-like) — see
# `generate_synthetic_texture()` — so Probe 1 always runs regardless.

TEST_TF = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])])

# ─── MODEL LOADERS ────────────────────────────────────────────────────────────
def load_pnet(ckpt, device):
    from exp1_ablation_FIXED import AblationModel
    m = AblationModel(use_se=True, use_srm=True, similarity='cosine')
    state = torch.load(ckpt, map_location=device)
    m.load_state_dict(state.get('model', state), strict=False)
    m.eval().to(device)
    def fwd(x):
        out = m(x)
        return out[0] if isinstance(out, tuple) else out
    return m, fwd

def load_blackbox(ckpt, device):
    import timm
    class _Plain(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = timm.create_model('convnext_tiny', pretrained=False,
                                         num_classes=NUM_CLASSES)
        def forward(self, x): return self.net(x)
    bb = _Plain()
    state = torch.load(ckpt, map_location=device)
    bb.load_state_dict(state.get('model', state), strict=False)
    bb.eval().to(device)
    return bb, bb

# ════════════════════════════════════════════════════════════════════════════
# PROBE 1 — SYNTHETIC BACKGROUND REPLACEMENT
# ════════════════════════════════════════════════════════════════════════════

def segment_leaf(pil_img, sat_thresh=25, morph_k=5):
    arr = np.array(pil_img.convert('RGB'))
    hsv = cv2.cvtColor(arr, cv2.COLOR_RGB2HSV)
    _, mask = cv2.threshold(hsv[:,:,1], sat_thresh, 255, cv2.THRESH_BINARY)
    k = np.ones((morph_k,morph_k), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  k)
    return (mask > 0).astype(np.uint8)


def generate_synthetic_texture(size, kind, seed=None):
    """
    Fallback procedural texture generator — used when no external texture
    dataset is mounted. Produces plausible 'field-like' backgrounds
    (soil, foliage-blur, sky) via layered coloured noise + blur, so Probe 1
    never silently no-ops for lack of a texture dataset.
    """
    rng = np.random.RandomState(seed)
    base_colours = {
        'soil':    (101, 67, 33),
        'foliage': (60, 110, 50),
        'sky':     (140, 170, 200),
        'wood':    (133, 94, 66),
    }
    colour = base_colours.get(kind, (110, 110, 110))
    noise  = rng.randint(0, 60, (size, size, 3)).astype(np.int16)
    base   = np.array(colour, dtype=np.int16).reshape(1,1,3)
    img    = np.clip(base + noise - 30, 0, 255).astype(np.uint8)
    img    = cv2.GaussianBlur(img, (9,9), 0)
    return Image.fromarray(img)


def load_texture_bank(n_textures=30):
    """Loads real textures if TEXTURE_DIR exists, else procedural fallback."""
    textures = []
    if TEXTURE_DIR and os.path.isdir(TEXTURE_DIR):
        paths = list(Path(TEXTURE_DIR).rglob("*.jpg"))[:n_textures]
        for p in paths:
            try:
                textures.append(Image.open(p).convert('RGB')
                                .resize((IMG_SIZE, IMG_SIZE)))
            except Exception:
                pass
    if not textures:
        print("  No texture dataset found — using procedural fallback textures.")
        kinds = ['soil','foliage','sky','wood']
        for i in range(n_textures):
            textures.append(generate_synthetic_texture(
                IMG_SIZE, kinds[i % len(kinds)], seed=i))
    return textures


def swap_background(pil_img, texture_bank, rng):
    leaf_mask = segment_leaf(pil_img)
    tex = texture_bank[rng.randint(len(texture_bank))]
    tex_np = np.array(tex)
    img_np = np.array(pil_img.convert('RGB'))
    out = np.where(leaf_mask[...,None].astype(bool), img_np, tex_np)
    return Image.fromarray(out.astype(np.uint8))


class BackgroundSwapDataset(Dataset):
    def __init__(self, root, transform, texture_bank, seed=0):
        self.ds  = datasets.ImageFolder(root, transform=None)
        self.tf  = transform
        self.tex = texture_bank
        self.rng = np.random.RandomState(seed)
    def __len__(self): return len(self.ds)
    def __getitem__(self, i):
        path, label = self.ds.samples[i]
        img = Image.open(path).convert('RGB').resize(
            (IMG_SIZE, IMG_SIZE), Image.BICUBIC)
        img = swap_background(img, self.tex, self.rng)
        return self.tf(img), label


@torch.no_grad()
def eval_acc(fwd, loader, device):
    c = t = 0
    for imgs, tgts in loader:
        logits = fwd(imgs.to(device))
        c += (logits.argmax(1) == tgts.to(device)).sum().item()
        t += imgs.size(0)
    return c / t


def run_probe1(models, device, test_dir):
    print("\n" + "="*60 + "\nPROBE 1: Synthetic Background Replacement\n" + "="*60)

    texture_bank = load_texture_bank(30)
    orig_ds = datasets.ImageFolder(test_dir, TEST_TF)
    orig_ld = DataLoader(orig_ds, BATCH_SIZE, shuffle=False, num_workers=4)

    swap_ds = BackgroundSwapDataset(test_dir, TEST_TF, texture_bank, seed=123)
    swap_ld = DataLoader(swap_ds, BATCH_SIZE, shuffle=False, num_workers=4)

    # Qualitative sample grid
    fig, axes = plt.subplots(2, 5, figsize=(15,6))
    sample_idx = np.random.RandomState(0).choice(len(swap_ds.ds), 5, replace=False)
    for j, idx in enumerate(sample_idx):
        path, _ = swap_ds.ds.samples[idx]
        orig = Image.open(path).convert('RGB').resize((IMG_SIZE,IMG_SIZE))
        swapped = swap_background(orig, texture_bank, np.random.RandomState(idx))
        axes[0,j].imshow(orig); axes[0,j].axis('off')
        axes[1,j].imshow(swapped); axes[1,j].axis('off')
    axes[0,0].set_ylabel('Original', fontsize=10)
    axes[1,0].set_ylabel('Background-swapped', fontsize=10)
    plt.suptitle('Probe 1 Qualitative Check: Background Swap')
    plt.tight_layout()
    plt.savefig(os.path.join(RESULTS_DIR,'probe1_qualitative.png'), dpi=150)
    plt.close()

    results = {}
    for name, (model, fwd) in models.items():
        orig_acc = eval_acc(fwd, orig_ld, device)
        swap_acc = eval_acc(fwd, swap_ld, device)
        delta = (swap_acc - orig_acc) * 100
        results[name] = {
            'original_acc': round(orig_acc*100, 2),
            'swapped_acc':  round(swap_acc*100, 2),
            'delta_pp':     round(delta, 2),
        }
        print(f"  {name:<20}  orig={orig_acc*100:.2f}%  "
              f"swapped={swap_acc*100:.2f}%  Δ={delta:+.2f}pp")

    # Relative robustness comparison
    if 'POWER-ProtoPNet' in results and 'BlackBox' in results:
        p, b = results['POWER-ProtoPNet']['delta_pp'], results['BlackBox']['delta_pp']
        more_robust = 'POWER-ProtoPNet' if p > b else 'BlackBox'
        print(f"\n  More robust to background swap: {more_robust} "
              f"({max(p,b):+.2f}pp vs {min(p,b):+.2f}pp)")
        results['_comparison'] = {
            'more_robust_model': more_robust,
            'pnet_delta': p, 'blackbox_delta': b,
        }
    return results

# ════════════════════════════════════════════════════════════════════════════
# PROBE 2 — IMAGENET-C STYLE CORRUPTION ROBUSTNESS
# ════════════════════════════════════════════════════════════════════════════

def corrupt_gaussian_noise(img_np, severity):
    sigma = [0.04, 0.08, 0.12][severity-1] * 255
    noise = np.random.normal(0, sigma, img_np.shape)
    return np.clip(img_np + noise, 0, 255).astype(np.uint8)

def corrupt_defocus_blur(img_np, severity):
    k = [3, 7, 11][severity-1]
    return cv2.GaussianBlur(img_np, (k,k), 0)

def corrupt_brightness(img_np, severity):
    factor = [1.3, 1.6, 2.0][severity-1]
    hsv = cv2.cvtColor(img_np, cv2.COLOR_RGB2HSV).astype(np.float32)
    hsv[...,2] = np.clip(hsv[...,2]*factor, 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)

def corrupt_contrast(img_np, severity):
    factor = [0.6, 0.4, 0.25][severity-1]
    mean = img_np.mean()
    return np.clip((img_np-mean)*factor + mean, 0, 255).astype(np.uint8)

def corrupt_jpeg(img_np, severity):
    quality = [50, 25, 10][severity-1]
    ok, enc = cv2.imencode('.jpg', cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR),
                           [cv2.IMWRITE_JPEG_QUALITY, quality])
    dec = cv2.imdecode(enc, cv2.IMREAD_COLOR)
    return cv2.cvtColor(dec, cv2.COLOR_BGR2RGB)

CORRUPTIONS = {
    'gaussian_noise': corrupt_gaussian_noise,
    'defocus_blur':   corrupt_defocus_blur,
    'brightness':     corrupt_brightness,
    'contrast':       corrupt_contrast,
    'jpeg':           corrupt_jpeg,
}

class CorruptedDataset(Dataset):
    def __init__(self, root, transform, corruption_fn, severity):
        self.ds = datasets.ImageFolder(root, transform=None)
        self.tf = transform
        self.fn = corruption_fn
        self.severity = severity
    def __len__(self): return len(self.ds)
    def __getitem__(self, i):
        path, label = self.ds.samples[i]
        img = Image.open(path).convert('RGB').resize((IMG_SIZE,IMG_SIZE))
        arr = self.fn(np.array(img), self.severity)
        return self.tf(Image.fromarray(arr)), label


def run_probe2(models, device, test_dir, n_subsample=1500):
    """
    Evaluates corruption robustness on a stratified subsample (n_subsample
    images) rather than the full 5,700-image test set per corruption×
    severity combination, since the full grid is 5 corruptions × 3
    severities × full test set × N models — prohibitively slow otherwise.
    Subsampling preserves class balance via deterministic stride sampling.
    """
    print("\n" + "="*60 + "\nPROBE 2: Corruption Robustness (mCE)\n" + "="*60)

    full_ds = datasets.ImageFolder(test_dir)
    n_total = len(full_ds)
    stride  = max(1, n_total // n_subsample)
    sub_idx = list(range(0, n_total, stride))[:n_subsample]

    results = {name: {} for name in models}

    for corr_name, corr_fn in CORRUPTIONS.items():
        for sev in [1, 2, 3]:
            ds  = CorruptedDataset(test_dir, TEST_TF, corr_fn, sev)
            sub = torch.utils.data.Subset(ds, sub_idx)
            ld  = DataLoader(sub, BATCH_SIZE, shuffle=False, num_workers=4)

            for name, (model, fwd) in models.items():
                acc = eval_acc(fwd, ld, device)
                results[name][f"{corr_name}_sev{sev}"] = round(acc*100, 2)
            print(f"  {corr_name} sev={sev}: "
                  + "  ".join(f"{n}={results[n][f'{corr_name}_sev{sev}']:.1f}%"
                              for n in models))

    # Mean Corruption Error (mCE), normalised against the first model
    # listed as reference (typically the black-box), per Hendrycks 2019
    ref_name = list(models.keys())[0]
    summary = {}
    for name in models:
        errs = [100 - results[name][k] for k in results[name]]
        ref_errs = [100 - results[ref_name][k] for k in results[ref_name]]
        mce = float(np.mean(errs))
        rel_mce = float(np.mean(errs) / (np.mean(ref_errs) + 1e-9))
        summary[name] = {'mCE': round(mce,2), 'relative_mCE': round(rel_mce,3)}
        print(f"  {name}: mCE={mce:.2f}%  relative_mCE={rel_mce:.3f} "
              f"(ref={ref_name})")

    results['_summary'] = summary
    results['_n_subsample'] = len(sub_idx)
    return results

# ════════════════════════════════════════════════════════════════════════════
# PROBE 3 — PLANTDOC ZERO-SHOT (OPTIONAL)
# ════════════════════════════════════════════════════════════════════════════

# Template mapping — PlantDoc and PlantWild v3/PlantVillage use different
# label taxonomies. You MUST verify and complete this mapping manually by
# inspecting both class lists; entries left as None are skipped (no
# confident correspondence) and excluded from accuracy computation rather
# than silently mismatched.
PLANTDOC_TO_PLANTWILD = {
    "Tomato leaf late blight":      "Tomato___Late_blight",
    "Tomato leaf early blight":     "Tomato___Early_blight",
    "Tomato leaf bacterial spot":   "Tomato___Bacterial_spot",
    "Tomato leaf":                  "Tomato___healthy",
    "Apple Scab Leaf":              "Apple___Apple_scab",
    "Apple leaf":                   "Apple___healthy",
    "Corn leaf blight":             "Corn___Northern_Leaf_Blight",
    "Corn Gray leaf spot":          "Corn___Cercospora_leaf_spot",
    # NOTE: extend this dict after inspecting your actual PlantDoc folder
    # names — they vary by download source. Anything not mapped here is
    # excluded from the zero-shot evaluation, not guessed.
}

def run_probe3(models, device):
    if not PLANTDOC_ROOT or not os.path.isdir(PLANTDOC_ROOT):
        print("\nPROBE 3 SKIPPED: PlantDoc not mounted at "
              f"{PLANTDOC_ROOT}. Set PLANTDOC_ROOT and the class mapping "
              "dict above to enable. This is the strongest single piece "
              "of evidence reviewers will want — prioritise obtaining it "
              "if at all possible (PlantDoc is public: "
              "https://github.com/pratikkayal/PlantDoc-Dataset).")
        return None

    print("\n" + "="*60 + "\nPROBE 3: PlantDoc Zero-Shot Evaluation\n" + "="*60)
    pd_ds = datasets.ImageFolder(PLANTDOC_ROOT, transform=None)
    pwild_classes = datasets.ImageFolder(
        os.path.join(DATASET_ROOT,'test')).classes

    # Build filtered sample list using only mapped classes
    valid_samples = []
    for path, label_idx in pd_ds.samples:
        pd_class_name = pd_ds.classes[label_idx]
        mapped = PLANTDOC_TO_PLANTWILD.get(pd_class_name)
        if mapped and mapped in pwild_classes:
            valid_samples.append((path, pwild_classes.index(mapped)))

    if not valid_samples:
        print("  No PlantDoc classes matched the mapping dict. "
              "Update PLANTDOC_TO_PLANTWILD with your actual folder names.")
        return None

    print(f"  Mapped {len(valid_samples)}/{len(pd_ds.samples)} "
          f"PlantDoc images to {len(set(s[1] for s in valid_samples))} "
          f"overlapping PlantWild v3 classes.")

    class _MappedDS(Dataset):
        def __init__(self, samples, tf): self.samples, self.tf = samples, tf
        def __len__(self): return len(self.samples)
        def __getitem__(self, i):
            path, label = self.samples[i]
            img = Image.open(path).convert('RGB')
            return self.tf(img), label

    ds = _MappedDS(valid_samples, TEST_TF)
    ld = DataLoader(ds, BATCH_SIZE, shuffle=False, num_workers=4)

    results = {}
    for name, (model, fwd) in models.items():
        acc = eval_acc(fwd, ld, device)
        results[name] = round(acc*100, 2)
        print(f"  {name}: {acc*100:.2f}% zero-shot on PlantDoc subset")
    results['_n_images'] = len(valid_samples)
    results['_n_classes_overlap'] = len(set(s[1] for s in valid_samples))
    return results

# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")

    pnet_model, pnet_fwd = load_pnet(PNET_CHECKPOINT, device)
    bb_model, bb_fwd     = load_blackbox(BB_CHECKPOINT, device)
    models = {
        'POWER-ProtoPNet': (pnet_model, pnet_fwd),
        'BlackBox':        (bb_model, bb_fwd),
    }

    test_dir = os.path.join(DATASET_ROOT, 'test')
    all_results = {}

    all_results['probe1_background_swap'] = run_probe1(models, device, test_dir)
    all_results['probe2_corruption']       = run_probe2(models, device, test_dir)
    all_results['probe3_plantdoc']         = run_probe3(models, device)

    out = os.path.join(RESULTS_DIR, 'robustness_results.json')
    with open(out, 'w') as f:
        json.dump(all_results, f, indent=2, default=str)
    print(f"\nAll robustness results saved: {out}")

    # ── Paper text ─────────────────────────────────────────────
    p1 = all_results['probe1_background_swap']
    p2 = all_results['probe2_corruption']
    print(f"""
─────────────────────────────────────────────────────────────
SECTION VI-D DRAFT TEXT — Field-Condition Robustness:
─────────────────────────────────────────────────────────────
To evaluate the deployment risk implied by the global SHAP audit,
we replaced PlantWild v3 test backgrounds with naturalistic
textures while preserving the leaf region. Accuracy changed from
{p1['POWER-ProtoPNet']['original_acc']:.2f}% to
{p1['POWER-ProtoPNet']['swapped_acc']:.2f}% for POWER-ProtoPNet
(Δ={p1['POWER-ProtoPNet']['delta_pp']:+.2f}pp), versus
{p1['BlackBox']['original_acc']:.2f}% to {p1['BlackBox']['swapped_acc']:.2f}%
for the black-box baseline (Δ={p1['BlackBox']['delta_pp']:+.2f}pp).

Under standard corruption protocols (Gaussian noise, defocus blur,
brightness/contrast shift, JPEG compression at 3 severities;
Hendrycks & Dietterich, ICLR 2019), POWER-ProtoPNet achieved
mCE={p2['_summary']['POWER-ProtoPNet']['mCE']:.2f}% versus
{p2['_summary']['BlackBox']['mCE']:.2f}% for the black-box baseline.
─────────────────────────────────────────────────────────────""")


if __name__ == "__main__":
    main()
