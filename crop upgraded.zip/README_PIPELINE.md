# POWER-ProtoPNet Experiment Pipeline — Run Order & Dependencies

This directory contains the FIXED and NEW experiment scripts produced
during the technical code review. Run them in this order; later scripts
depend on checkpoints/results produced by earlier ones.

## Run Order

| Step | Script | Depends On | Produces | Est. GPU-Hours |
|------|--------|-----------|----------|------------------|
| 1 | `exp1_ablation_FIXED.py` | dataset only | `ablation_ckpts/*.pth`, `ablation_results.csv` | ~60–100h (9 variants × 3 seeds) |
| 2 | `exp2_multiseed_FIXED.py` | dataset only | `multiseed/pnet_seed_*.json`, `multiseed/bb_model_seed_*.pth` | ~55h (4 PNet + 5 BB seeds) |
| 3 | `exp3_causal_shap_FIXED.py` | step 2 (`bb_model_seed_0.pth`), a trained PNet checkpoint | `causal_shap/*.json`, `*.png` | ~2–3h |
| 4 | `exp4_pipnet_baseline.py` | dataset only | `pipnet/pipnet_summary.json` | ~25–30h (3 seeds) |
| 5 | `exp5_xai_metrics.py` | step 1 or 2 (any PNet checkpoint) | `xai_metrics/xai_metrics.json` | ~1.5–2h |
| 6 | `exp6_cross_dataset_robustness.py` | step 2 (PNet + BB checkpoints) | `robustness/robustness_results.json`, qualitative PNGs | ~1.5–2h (Probes 1–2); Probe 3 varies |
| 7 | `exp7_prototype_analysis.py` | a trained PNet checkpoint | `prototype_analysis/*.json`, gallery PNGs | ~0.5h |
| 8 | `exp8_efficiency_benchmark.py` | model class definitions only (no checkpoint needed) | `efficiency/efficiency_results.json` | ~10 min |
| 9 | `exp9_master_aggregator.py` | ALL of the above | `final_tables/*.tex`, `all_results_manifest.json` | ~1 min |

## Critical Path for a Minimum-Viable Submission

If GPU budget is constrained, prioritise in this order (matches the
CRITICAL items in the pre-writing audit):

1. `exp2_multiseed_FIXED.py` — without this, there is no statistically
   defensible headline result.
2. `exp1_ablation_FIXED.py` — without this, no architectural claim can
   be made. Run at minimum variants V1, V2, V3, V6, V8 with 1 seed each
   before attempting all 9×3.
3. `exp4_pipnet_baseline.py` — required baseline; the official repo
   should be attempted first (see script header), minimal fallback
   otherwise — disclose this in the paper's reproducibility section if
   the fallback is used.
4. `exp6_cross_dataset_robustness.py` — Probes 1–2 require no external
   dataset and should always be run; Probe 3 (PlantDoc) is the single
   strongest piece of evidence for deployment claims and is worth the
   effort to obtain the dataset.
5. `exp3_causal_shap_FIXED.py` and `exp7_prototype_analysis.py` — both
   cheap (hours, not days) and directly answer specific reviewer
   questions about causality and prototype quality.
6. `exp5_xai_metrics.py` and `exp8_efficiency_benchmark.py` — cheapest,
   highest leverage-per-GPU-hour; do these whenever a spare hour appears.

## Known Limitations to Disclose in the Paper

- `exp4`'s minimal PIPNet is a faithful-but-simplified reimplementation
  (positive-only cosine similarity, orthogonality regularisation) used
  only if the official repository is unavailable in the training
  environment. If the fallback path was used for the reported numbers,
  this MUST be stated explicitly in the paper's experimental setup
  section — silently presenting fallback numbers as "PIPNet [10]"
  results would be a reproducibility violation.
- `exp5`'s Pointing Game uses an HSV-saturation leaf mask as a proxy for
  expert lesion annotations (leaf ≠ lesion). Report this as a stated
  limitation; the metric is directionally informative, not a substitute
  for ground-truth validation.
- `exp6` Probe 1's texture bank falls back to procedurally generated
  textures if no external texture dataset is mounted. Report which path
  was used — procedural textures are a weaker robustness test than real
  field photographs (Probe 3 / PlantDoc remains the gold standard).

## After Running Everything

Run `exp9_master_aggregator.py` once, point `RESULTS_ROOT` at wherever
you've collected all the individual results directories, and it will:
1. Tell you exactly what's still missing (`completeness_report.txt`)
2. Emit ready-to-paste LaTeX for Tables IV–X
3. Produce one manifest JSON for the supplementary material /
   reproducibility appendix

Do not hand-copy numbers from script stdout into the paper — use the
aggregator's output as the single source of truth, so a number changed
in one place cannot silently drift out of sync with another.
